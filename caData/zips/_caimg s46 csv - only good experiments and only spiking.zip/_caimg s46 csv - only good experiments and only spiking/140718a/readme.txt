Recording id: 140718a\
N cells: 206
F file for fluoresence (raw data); S file for spike estimations (deconvolved).
In both files 1st column is sweep number, 2nd column is time stamp, remaining columns are data.
Stimuli always cycle through three stimulus types: looming stimulus, full-field flash, scrambled stimulus.
